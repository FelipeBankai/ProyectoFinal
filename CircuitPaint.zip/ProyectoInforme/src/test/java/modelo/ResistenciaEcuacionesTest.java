/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Alumno
 */
public class ResistenciaEcuacionesTest {
    
    public ResistenciaEcuacionesTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testTransformarParalelo() {
        System.out.println("transformarParalelo");
        ResistenciaEcuaciones instance = new ResistenciaEcuaciones();
        double expResult = 0.5;
        double result = instance.transformarParalelo("2");
        assertEquals(expResult, result, 0.5);
    }

    @Test
    public void testTransformar_A_num() {
        System.out.println("Transformar_A_num");
        ResistenciaEcuaciones instance = new ResistenciaEcuaciones();
        double expResult = 3.0;
        double result = instance.transformar_A_num("3");
        assertEquals(expResult, result, 3.0);
    }
    @Test
    public void testVerificador(){
        System.out.println("Verificador");
        ResistenciaEcuaciones instance = new ResistenciaEcuaciones();
        int expResult = 5;
        int result = instance.verificador(0, "5");
        assertEquals(expResult, result, 5);
        
    
    }
    
}

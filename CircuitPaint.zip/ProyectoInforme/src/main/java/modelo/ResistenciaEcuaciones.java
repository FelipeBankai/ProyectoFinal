/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import javax.swing.JOptionPane;

/**
 *
 * @author Alumno
 */
public class ResistenciaEcuaciones {

    private static final double transformador = 1.0;

    public ResistenciaEcuaciones() {
        
    }

    public static double transformar_A_num(String text) {

        double resistenciaSerie = (Double.parseDouble(text));

        return resistenciaSerie;

    }

    public static double transformarParalelo(String text) {

        double resistenciaParalelo = (transformador / Double.parseDouble(text));

        return resistenciaParalelo;

    }
    
    public static int verificador(int n, String text) {

        while (n < 1 || n > 7) {
            JOptionPane.showMessageDialog(null, "Ingrese una cantidad entre 1 o 7");
            text = JOptionPane.showInputDialog("Cantidad de resistencias a utilizar Max. 7");
            n = Integer.parseInt(text);
        }
        return n;

    }

}

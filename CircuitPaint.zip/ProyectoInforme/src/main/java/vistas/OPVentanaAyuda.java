/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistas;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author Alumno
 */
public class OPVentanaAyuda extends JFrame{

    private OP_Ayuda ayuda;
    private OP_AyudaImagenes imagen;
    
    public OPVentanaAyuda(){
        
        inicializarComponentes();
        
    }
    
    public void inicializarComponentes(){
        
        BorderLayout border = new BorderLayout();
        this.setLayout(border);
        this.ayuda = new OP_Ayuda();
        this.add(this.ayuda, BorderLayout.WEST);
        
        this.imagen = new OP_AyudaImagenes();
        this.add(this.imagen, BorderLayout.EAST);
        this.setTitle( "CircuitPaint" );
        ImageIcon ImageIcon = new ImageIcon("atomo.png");
        Image image = ImageIcon.getImage();
        this.setIconImage(image);
        this.setBounds(200, 80, 963, 630);
        this.setVisible(true);
        
    
    }
    
}

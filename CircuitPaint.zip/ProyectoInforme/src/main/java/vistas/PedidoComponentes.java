/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistas;

import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import modelo.ResistenciaEcuaciones;

/**
 *
 * @author Alumno
 */
public class PedidoComponentes extends JPanel {

    public int componentes;
    public String ingresar;

    public PedidoComponentes() {

        inicializarComponentes();

    }

    public void inicializarComponentes() {

        try {

            this.ingresar = JOptionPane.showInputDialog("Cantidad de resistencias a utilizar Max. 7");
            this.componentes = Integer.parseInt(ingresar);
            if (componentes < 1 || componentes > 7) {

                componentes = ResistenciaEcuaciones.verificador(this.componentes, this.ingresar);

            }

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(this, "Debe ingresar numeros");

        }

    }

    public int getComponentes() {
        return componentes;
    }
    

}

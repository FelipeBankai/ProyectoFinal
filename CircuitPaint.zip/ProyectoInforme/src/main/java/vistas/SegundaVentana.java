/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistas;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JOptionPane;
import modelo.ResistenciaEcuaciones;

/**
 *
 * @author Alumno
 */
public class SegundaVentana extends JFrame implements ActionListener {

    private EsquemaPlatSup titulo;
    private EsquemaPlatEast boton;
    private EsquemaPlatCenter tabla;
    private EsquemaPlatInfe ayuda;

    private static int lineaBlancaInicioSerie = 50;
    private static int lineaBlancaFinalSerie = 120;

    private static int resistenciaPunto1Serie = 50;
    private static int resistenciaPunto2Serie = 60;
    private static int resistenciaPunto3Serie = 70;
    private static int resistenciaPunto4Serie = 120;

    private static int lineaParalela = 120;
    private static int lineaBlancaParalela = 120;

    private static int resistenciaPunto1Paralela = 120;
    private static int resistenciaPunto2Paralela = 95;
    private static int resistenciaPunto3Paralela = 145;

    private static double resistenciaEquiv;
    private static double corrienteTotal;

    private static String NumResSerie;
    private static int lugarNumResSerie = 80;//cambia de lugar el valor de una nueva resistencia

    private static String NumResParalel;
    private static int lugarNumResParalel = 55;

    private static int contador;
    private ArrayList<Double> totalParalelo = new ArrayList<>();

    public SegundaVentana() {

        inicializarComponentes();

    }

    public void inicializarComponentes() {

        this.titulo = new EsquemaPlatSup();
        this.add(this.titulo, BorderLayout.NORTH);

        this.boton = new EsquemaPlatEast();
        this.add(this.boton, BorderLayout.EAST);

        this.tabla = new EsquemaPlatCenter();
        this.add(this.tabla, BorderLayout.CENTER);

        this.ayuda = new EsquemaPlatInfe();
        this.add(this.ayuda, BorderLayout.SOUTH);

        this.titulo.buttonAtras.addActionListener(this);
        this.ayuda.ayuda.addActionListener(this);
        this.boton.checkResistenciaSerie.addActionListener(this);
        this.boton.buttonResistencia.addActionListener(this);
        this.boton.buttonVoltaje.addActionListener(this);
        this.boton.txtResistenciaEquiv.addActionListener(this);
        this.boton.buttonPuertaCerrar.addActionListener(this);
        this.boton.buttonPuertaRomper.addActionListener(this);
        this.boton.buttonBorrar.addActionListener(this);

        this.setTitle("CircuitPaint");
        ImageIcon ImageIcon = new ImageIcon("atomo.png");
        Image image = ImageIcon.getImage();
        this.setIconImage(image);
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);

        pidiendoDatos();

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (this.titulo.buttonAtras == e.getSource()) {

            PrimerVentana v1 = new PrimerVentana();
            v1.setVisible(true);
            borrarTodo();

            this.setVisible(false);
        }

        if (this.ayuda.ayuda == e.getSource()) {

            OPVentanaAyuda opv = new OPVentanaAyuda();
            opv.setVisible(true);
        }
        if (this.boton.buttonVoltaje == e.getSource()) {

            mostrarVoltaje();
            mostrarNumVoltaje();
            if (this.boton.txtResistenciaEquiv.getText()!=(null)) {
                    mostrarCorriente();
                }

        }

        if (this.boton.checkResistenciaSerie.isSelected()) {
            if (this.boton.buttonResistencia == e.getSource()) {

                try {
                    if (this.contador > 0) {
                        mostrarResistenciaSerie();//muestra dibujo de la resistencia en serie
                        numResSerie();//muestra la cantidad de la resistencia ingresada en pantalla
                        this.boton.txtResistencia.setText(null);
                    } else {
                        JOptionPane.showMessageDialog(null, "Maximo de resistencias ingresadas.");
                    }
                } catch (NumberFormatException nfe) {
                    JOptionPane.showMessageDialog(null, "Error digite un Valor Valido");
                }
                if (this.boton.txtVoltaje.getText() != (null)) {
                    mostrarCorriente();
                }

            }
        }

        if (this.boton.checkResistenciaParalelo.isSelected()) {
            if (this.boton.buttonResistencia == e.getSource()) {

                try {
                    if (this.contador > 0) {
                        mostrarResistenciaParalelo();
                        numResParalel();
                        this.boton.txtResistencia.setText(null);

                    } else {
                        JOptionPane.showMessageDialog(null, "Maximo de resistencias ingresadas.");
                    }
                } catch (NumberFormatException nfe) {
                    JOptionPane.showMessageDialog(null, "Error digite un Valor Valido");
                }
                if (this.boton.txtVoltaje.getText() != (null)) {
                    mostrarCorriente();
                }
            }

        }

        if (this.boton.buttonPuertaRomper == e.getSource()) {

            romperPuerta();

        }
        if (this.boton.buttonPuertaCerrar == e.getSource()) {

            cerrarPuerta();

        }

        if (this.boton.buttonBorrar == e.getSource()) {

            borrarTodo();
            pidiendoDatos();

        }

    }

    public void mostrarVoltaje() {

        Graphics g = this.tabla.getGraphics();
        g.setColor(Color.WHITE);
        g.drawLine(30, 200, 30, 275);
        g.setColor(Color.BLACK);
        g.drawLine(10, 200, 50, 200);
        g.drawLine(10, 275, 50, 275);
    }

    /**
     * muestra resistencia en serie
     */
    public void mostrarResistenciaSerie() {

        Graphics g = this.tabla.getGraphics();
        g.setColor(Color.white);
        g.drawLine(this.lineaBlancaInicioSerie, 50, this.lineaBlancaFinalSerie, 50);
        this.lineaBlancaInicioSerie = this.lineaBlancaInicioSerie + 100;
        this.lineaBlancaFinalSerie = this.lineaBlancaFinalSerie + 100;

        g.setColor(Color.black);
        g.drawLine(this.resistenciaPunto1Serie, 50, this.resistenciaPunto2Serie, 75);
        g.drawLine(this.resistenciaPunto2Serie, 75, this.resistenciaPunto3Serie, 25);

        this.resistenciaPunto2Serie = this.resistenciaPunto2Serie + 20;//cambio de punto

        g.drawLine(this.resistenciaPunto3Serie, 25, this.resistenciaPunto2Serie, 75);

        this.resistenciaPunto3Serie = this.resistenciaPunto3Serie + 20;//cambio de punto

        g.drawLine(this.resistenciaPunto2Serie, 75, this.resistenciaPunto3Serie, 25);

        this.resistenciaPunto2Serie = this.resistenciaPunto2Serie + 20;//cambio de punto

        g.drawLine(this.resistenciaPunto3Serie, 25, this.resistenciaPunto2Serie, 75);

        this.resistenciaPunto3Serie = this.resistenciaPunto3Serie + 20;//cambio de punto

        g.drawLine(this.resistenciaPunto2Serie, 75, this.resistenciaPunto3Serie, 25);
        g.drawLine(this.resistenciaPunto3Serie, 25, this.resistenciaPunto4Serie, 50);

        this.resistenciaPunto1Serie = this.resistenciaPunto1Serie + 100;
        this.resistenciaPunto2Serie = this.resistenciaPunto2Serie + 60;
        this.resistenciaPunto3Serie = this.resistenciaPunto3Serie + 60;
        this.resistenciaPunto4Serie = this.resistenciaPunto4Serie + 100;

        this.lineaParalela = this.lineaParalela + 100;
        this.lineaBlancaParalela = this.lineaBlancaParalela + 100;

        this.resistenciaPunto1Paralela = this.resistenciaPunto1Paralela + 100;
        this.resistenciaPunto2Paralela = this.resistenciaPunto2Paralela + 100;
        this.resistenciaPunto3Paralela = this.resistenciaPunto3Paralela + 100;

        sumarResistenciaSerie();

    }

    /**
     * Muestra resistencia en paralelo
     */
    public void mostrarResistenciaParalelo() {

        Graphics g = this.tabla.getGraphics();

        g.drawLine(this.lineaParalela, 50, this.lineaParalela, 500);

        g.setColor(Color.white);
        g.drawLine(this.lineaBlancaParalela, 140, this.lineaBlancaParalela, 210);

        g.setColor(Color.black);
        g.drawLine(this.resistenciaPunto1Paralela, 140, this.resistenciaPunto2Paralela, 150);
        g.drawLine(this.resistenciaPunto2Paralela, 150, this.resistenciaPunto3Paralela, 160);
        g.drawLine(this.resistenciaPunto3Paralela, 160, this.resistenciaPunto2Paralela, 170);
        g.drawLine(this.resistenciaPunto2Paralela, 170, this.resistenciaPunto3Paralela, 180);
        g.drawLine(this.resistenciaPunto3Paralela, 180, this.resistenciaPunto2Paralela, 190);
        g.drawLine(this.resistenciaPunto2Paralela, 190, this.resistenciaPunto3Paralela, 200);
        g.drawLine(this.resistenciaPunto3Paralela, 200, this.resistenciaPunto1Paralela, 210);

        this.lineaBlancaInicioSerie = this.lineaBlancaInicioSerie + 100;
        this.lineaBlancaFinalSerie = this.lineaBlancaFinalSerie + 100;
        this.resistenciaPunto1Serie = this.resistenciaPunto1Serie + 100;
        this.resistenciaPunto2Serie = this.resistenciaPunto2Serie + 100;
        this.resistenciaPunto3Serie = this.resistenciaPunto3Serie + 100;
        this.resistenciaPunto4Serie = this.resistenciaPunto4Serie + 100;

        this.lineaParalela = this.lineaParalela + 100;
        this.lineaBlancaParalela = this.lineaBlancaParalela + 100;

        this.resistenciaPunto1Paralela = this.resistenciaPunto1Paralela + 100;
        this.resistenciaPunto2Paralela = this.resistenciaPunto2Paralela + 100;
        this.resistenciaPunto3Paralela = this.resistenciaPunto3Paralela + 100;

        sumarResistenciaParalelo();

    }

    /**
     * Crea Puerta
     */
    public void romperPuerta() {

        Graphics g = this.tabla.getGraphics();

        g.drawLine(720, 300, 750, 380);
        g.setColor(Color.white);
        g.drawLine(720, 302, 720, 380);

    }

    /**
     * Cierra Puerta
     */
    public void cerrarPuerta() {

        Graphics g = this.tabla.getGraphics();
        g.setColor(Color.white);
        g.drawLine(720, 300, 750, 380);
        g.setColor(Color.black);
        g.drawLine(720, 300, 720, 380);

    }

    public void agregarParalelo() {

        this.totalParalelo.add(ResistenciaEcuaciones.transformarParalelo(this.boton.txtResistencia.getText()));//agrega un valor al arrays

        BigDecimal bd = new BigDecimal(ResistenciaEcuaciones.transformarParalelo(this.boton.txtResistencia.getText()));
        bd = bd.setScale(2, RoundingMode.HALF_UP);
        this.NumResParalel = "" + bd.doubleValue();
        if (contador == 0) {
            mostrarParalelo();
        }
    }

    public void mostrarParalelo() {

        double sumaDeParalelo = 0.0;
        for (int i = 0; i < totalParalelo.size(); i++) {//recorre el arrays

            sumaDeParalelo = totalParalelo.get(i) + sumaDeParalelo;//suma todos los elemenetos del arrays,se guarda en un double
        }
        double auxiliarParalelo = 1.0 / sumaDeParalelo;

        BigDecimal bd = new BigDecimal(this.resistenciaEquiv);
        bd = bd.setScale(2, RoundingMode.HALF_UP);

        BigDecimal aux = new BigDecimal(auxiliarParalelo);
        aux = aux.setScale(2, RoundingMode.HALF_UP);

        this.resistenciaEquiv = bd.doubleValue() + aux.doubleValue();
        this.boton.txtResistenciaEquiv.setText("" + resistenciaEquiv);
    }

    public void sumarResistenciaParalelo() {
        contador--;
        agregarParalelo();

    }

    public double transformarSerie() {

        double resistenciaSerie = (ResistenciaEcuaciones.transformar_A_num(this.boton.txtResistencia.getText()));

        return resistenciaSerie;
    }

    public void sumarResistenciaSerie() {
        this.contador--;
        double auxiliarSerie = transformarSerie();

        this.NumResSerie = "" + auxiliarSerie;

        this.resistenciaEquiv = auxiliarSerie + resistenciaEquiv;
        this.boton.txtResistenciaEquiv.setText("" + resistenciaEquiv);
    }

    /**
     * Muestra resistencia en serie en pantalla
     */
    public void numResSerie() {

        Graphics g = this.tabla.getGraphics();

        g.drawString(this.NumResSerie + " Ω", this.lugarNumResSerie, 100);

        this.lugarNumResSerie = this.lugarNumResSerie + 100;
        this.lugarNumResParalel = this.lugarNumResParalel + 100;
    }

    /**
     * Muestra resistencia en paralelo en pantalla
     */
    public void numResParalel() {

        Graphics g = this.tabla.getGraphics();

        g.drawString(this.NumResParalel + " Ω", this.lugarNumResParalel, 170);

        this.lugarNumResSerie = this.lugarNumResSerie + 100;
        this.lugarNumResParalel = this.lugarNumResParalel + 100;
    }

    public void mostrarNumVoltaje() {

        Graphics g = this.tabla.getGraphics();
        g.setColor(Color.white);
        g.fillRect(50, 220, 60, 245);
        g.setColor(Color.black);
        g.drawString(this.boton.txtVoltaje.getText() + " A", 70, 240);

    }

    public void mostrarCorriente() {

        this.corrienteTotal = (ResistenciaEcuaciones.transformar_A_num(this.boton.txtVoltaje.getText())) / this.resistenciaEquiv;

        BigDecimal bd = new BigDecimal(this.corrienteTotal);
        bd = bd.setScale(2, RoundingMode.HALF_UP);
        this.boton.txtCorriente.setText("" + bd.doubleValue());

    }

    public void borrarTodo() {

        Graphics g = this.tabla.getGraphics();

        g.setColor(Color.white);
        g.fillRect(10, 20, 750, 500);
        g.setColor(Color.black);
        g.drawRect(30, 50, 690, 450);

        this.boton.txtVoltaje.setText(null);
        this.boton.txtResistencia.setText(null);
        this.boton.txtResistenciaEquiv.setText(null);
        this.boton.txtCorriente.setText(null);

        this.lineaBlancaInicioSerie = 50;
        this.lineaBlancaFinalSerie = 120;

        this.resistenciaPunto1Serie = 50;
        this.resistenciaPunto2Serie = 60;
        this.resistenciaPunto3Serie = 70;
        this.resistenciaPunto4Serie = 120;
        this.lugarNumResSerie = 80;

        this.lineaParalela = 120;
        this.lineaBlancaParalela = 120;

        this.resistenciaPunto1Paralela = 120;
        this.resistenciaPunto2Paralela = 95;
        this.resistenciaPunto3Paralela = 145;
        this.lugarNumResParalel = 55;

        this.resistenciaEquiv = 0;
        this.corrienteTotal = 0;
        this.totalParalelo.clear();

    }

    public void pidiendoDatos() {

        PedidoComponentes pedir = new PedidoComponentes();
        this.contador = pedir.getComponentes();

    }

}

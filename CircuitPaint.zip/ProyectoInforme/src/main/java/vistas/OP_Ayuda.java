/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistas;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author Alumno
 */
public class OP_Ayuda extends JPanel {

    private JTextArea instrucciones;

    public OP_Ayuda() {

        inicializarComponentes();

    }

    public void inicializarComponentes() {

        this.instrucciones = new JTextArea(10, 20);
        Font fuente=new Font("Dialog", Font.BOLD, 15);
        this.setBackground(Color.WHITE);
        this.instrucciones.setFont(fuente);
        this.instrucciones.setBackground(Color.BLACK);
        this.instrucciones.setText("Hola Usuario este programa le ayudará a realizar sus ejercicios de circuitos\n"
                + "electronicos de una manera más ergonomica y sencilla. Mostrando además\n"
                + "dibujos de como se veria un circuito como tal.\n"
                + "\n"
                + "Este programa tiene varios tipos de funciones que se detallarán a continuación\n"
                + "\n"
                + "     -El cálculo de las resistencias estará mostrada en la casilla de resistencia total\n"
                + "en donde el usuario podrá ingresar una cantidad de resistencia en la\n"
                + "casilla en que se indica y puede después seleccionar si la quiere en serie o paralelo,\n"
                + "esto se debe a que una resistencia X en serie no es lo mismo que una en paralelo (Ver Fig 1) \n"
                + "\n"
                + "Para los ejercicios con resistencias en paralelo, estas se calculan al finalizar\n"
                + "el esquema, es decir el programa va a ir actualizando la resistencia total solo con\n"
                + "las resistencias en serie ingresadas, para que al final suma las paralelas con una\n"
                + "formula especial(Ver Fig 2).\n"
                + "\n"
                + "     -Para el calculo de la corriente el usuario tendrá que ingresar el voltaje en la casilla\n"
                + "señalada, y cuando la resistencia total ya este ingresada el programa hará el calculo\n"
                + "respectivo para calcular la corriente(Ver Fig 3).\n"
                + "\n"
                + "     -Como detalle, en la parte inferior derecha se encontrará un boton para borrar\n"
                + "el esquema, lo que provocará el reinicio de todos los datos, haciendo que la app pida\n"
                + "nuevamente la cantidad de resistencias a utilizar\n");
        this.add(this.instrucciones);
        this.instrucciones.setEnabled(false);

    }

}

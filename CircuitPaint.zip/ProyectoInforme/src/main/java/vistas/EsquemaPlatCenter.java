/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistas;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author Alumno
 */
public class EsquemaPlatCenter extends JPanel {

    public JTextArea tablita;
    
    public EsquemaPlatCenter() {

        inicializarComponentes();

    }

    public void inicializarComponentes() {
        
        this.tablita = new JTextArea(33, 69);
        this.setBackground(Color.CYAN);
        this.tablita.setEnabled(false);
        this.add(this.tablita);
    }

    public void paint(Graphics g){
    
        super.paint(g);
        
        g.drawRect(30, 50, 690, 450);
        
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistas;

import static com.sun.org.apache.xpath.internal.axes.HasPositionalPredChecker.check;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.SystemColor;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

/**
 *
 * @author Alumno
 */
public class EsquemaPlatEast extends JPanel implements KeyListener {

    private JLabel labelVoltaje;
    public JTextField txtVoltaje;
    public JButton buttonVoltaje;

    private JLabel labelResistencia;
    public JTextField txtResistencia;
    public JRadioButton checkResistenciaSerie;
    public JRadioButton checkResistenciaParalelo;
    public ButtonGroup check;

    public JButton buttonResistencia;

    private JLabel labelResistenciaEquiv;
    public JTextField txtResistenciaEquiv;

    private JLabel labelCorriente;
    public JTextField txtCorriente;

    private JLabel labelPuerta;
    public JButton buttonPuertaCerrar;
    public JButton buttonPuertaRomper;

    public JButton buttonBorrar;

    public EsquemaPlatEast() {

        inicializarComponentes();

    }

    public void inicializarComponentes() {

        GridLayout grid = new GridLayout(14, 3);
        this.setLayout(grid);
        this.setBackground(Color.CYAN);
        Font fuente = new Font("Dialog", Font.ROMAN_BASELINE, 20);
        TitledBorder border = BorderFactory.createTitledBorder("Datos que puede utilizar");
        border.setTitleFont(fuente);
        border.setTitleColor(Color.red);

        this.setBorder(border);

        Font guion = new Font("Dialog", Font.ROMAN_BASELINE, 50);

        //PrimerComponente
        this.labelVoltaje = new JLabel("Ingrese Voltaje");
        this.labelVoltaje.setFont(fuente);
        this.labelVoltaje.setForeground(Color.blue);
        this.add(this.labelVoltaje);
        this.add(new JLabel("   ---------")).setFont(guion);
        this.add(new JLabel("-------")).setFont(guion);
        this.txtVoltaje = new JTextField();
        this.txtVoltaje.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();

                if (Character.isLetter(c)) {
                    getToolkit().beep();

                    e.consume();

                }

            }

            @Override
            public void keyPressed(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }
        });
        this.add(this.txtVoltaje);
        this.add(new JLabel(""));
        this.buttonVoltaje = new JButton("Aceptar");
        this.add(this.buttonVoltaje);

        //SegundoComponente
        this.labelResistencia = new JLabel("Ingrese Resistencias");
        this.labelResistencia.setForeground(Color.blue);
        this.labelResistencia.setFont(fuente);
        this.add(this.labelResistencia);
        this.add(new JLabel("   ---------")).setFont(guion);
        this.add(new JLabel("-------")).setFont(guion);

        this.txtResistencia = new JTextField();
        this.txtResistencia.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();

                if (Character.isLetter(c)) {
                    getToolkit().beep();

                    e.consume();

                }

            }

            @Override
            public void keyPressed(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }
        });
        this.add(this.txtResistencia);
        this.checkResistenciaSerie = new JRadioButton("Serie");
        this.checkResistenciaSerie.setBackground(Color.cyan);//cambiando color
        this.add(this.checkResistenciaSerie);
        this.checkResistenciaParalelo = new JRadioButton("Paralelo");
        this.checkResistenciaParalelo.setBackground(Color.CYAN);
        this.add(this.checkResistenciaParalelo);

        this.add(new JLabel(""));
        this.add(new JLabel(""));
        this.buttonResistencia = new JButton("Aceptar");
        this.add(this.buttonResistencia);

        this.check = new ButtonGroup();//crear check que no se pueden repetir
        check.add(checkResistenciaSerie);
        check.add(checkResistenciaParalelo);

        //TerComponente
        this.labelResistenciaEquiv = new JLabel("Resistencia Total");
        this.labelResistenciaEquiv.setForeground(Color.blue);
        this.labelResistenciaEquiv.setFont(fuente);
        this.add(this.labelResistenciaEquiv);
        this.add(new JLabel("   ---------")).setFont(guion);
        this.add(new JLabel("-------")).setFont(guion);

        this.add(new JLabel(""));
        this.txtResistenciaEquiv = new JTextField();
        this.txtResistenciaEquiv.setEditable(false);
        this.txtResistenciaEquiv.setBackground(SystemColor.WHITE);
        this.add(this.txtResistenciaEquiv);
        this.add(new JLabel(""));

        //CuartoComponente
        this.labelCorriente = new JLabel("Corriente total");
        this.labelCorriente.setFont(fuente);
        this.labelCorriente.setForeground(Color.blue);
        this.add(this.labelCorriente);
        this.add(new JLabel("   ---------")).setFont(guion);
        this.add(new JLabel("-------")).setFont(guion);

        this.add(new JLabel(""));
        this.txtCorriente = new JTextField();
        this.txtCorriente.setEditable(false);
        this.txtCorriente.setBackground(SystemColor.WHITE);
        this.add(this.txtCorriente);
        this.add(new JLabel(""));

        //QuientoComponente
        this.labelPuerta = new JLabel("Ingrese puerta");
        this.labelPuerta.setForeground(Color.blue);
        this.labelPuerta.setFont(fuente);
        this.add(this.labelPuerta);
        this.add(new JLabel("   ---------")).setFont(guion);
        this.add(new JLabel("-------")).setFont(guion);

        ImageIcon imgHacer = new ImageIcon("hacer.jpg");
        this.buttonPuertaCerrar = new JButton(imgHacer);
        this.add(this.buttonPuertaCerrar);
        this.add(new JLabel(""));
        ImageIcon imgRomper = new ImageIcon("romper.jpg");
        this.buttonPuertaRomper = new JButton(imgRomper);
        this.add(this.buttonPuertaRomper);

        //SextoComponente
        this.add(new JLabel("  ---------")).setFont(guion);
        this.add(new JLabel("-----------")).setFont(guion);
        this.add(new JLabel("-------")).setFont(guion);
        
        this.add(new JLabel("  ---------")).setFont(guion);
        this.add(new JLabel("-----------")).setFont(guion);
        this.add(new JLabel("-------")).setFont(guion);
        
        this.add(new JLabel("  ---------")).setFont(guion);
        this.add(new JLabel("-----------")).setFont(guion);
        this.buttonBorrar = new JButton("Borrar Esquema");
        this.add(this.buttonBorrar);

    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

}

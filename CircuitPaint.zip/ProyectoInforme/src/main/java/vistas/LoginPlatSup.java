/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistas;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Alumno
 */
public class LoginPlatSup extends JPanel{

    private JLabel titulo;
    public JButton butonExis;
    
    public LoginPlatSup() {
    
        inicializarComponentes();
        
    }
    
    public void inicializarComponentes(){
    
        this.setBackground(Color.CYAN);
        
        Font fuente=new Font("Dialog", Font.BOLD, 25);
        this.titulo = new JLabel("Ingrese sus datos");
        this.titulo.setFont(fuente);
        this.titulo.setBackground(Color.BLUE);
        this.add(this.titulo);
        
        this.add(new JLabel("         "));
        this.butonExis = new JButton("Salir");
        this.butonExis.setBackground(Color.GRAY);
        this.add(this.butonExis);
    
    }
    
    
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistas;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Alumno
 */
public class LoginPlatInfe extends JPanel{

    public JButton entrar;
    
    public LoginPlatInfe() {
    
        inicializarComponentes();
    
    }
    
    public void inicializarComponentes(){
    
        FlowLayout flow = new FlowLayout();
        this.setLayout(flow);
        
        this.setBackground(Color.CYAN);
        Font fuente=new Font("Dialog", Font.BOLD, 20);
        
        
        this.add(new JLabel("                                                                    "));
        
        this.entrar = new JButton("Entrar");
        this.entrar.setFont(fuente);
        this.entrar.setBackground(Color.LIGHT_GRAY);
        this.add(this.entrar);
    
    }
    
}

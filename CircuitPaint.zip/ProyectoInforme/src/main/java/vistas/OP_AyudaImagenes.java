/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistas;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Alumno
 */
public class OP_AyudaImagenes extends JPanel{
    
    private JLabel etiqueta1;
    private JLabel etiqueta2;
    private JLabel etiqueta3;
    private ImageIcon Fig1;
    private ImageIcon Fig2;
    private ImageIcon Fig3;

    public OP_AyudaImagenes() {
    
        inicializarComponentes();
        
    }
    
    public void inicializarComponentes(){
    
        GridLayout grid = new GridLayout(9, 1);
        this.setLayout(grid);
        
        this.setBackground(Color.WHITE);
        
        this.Fig1 = new ImageIcon("Fig1.jpg");
        this.etiqueta1 = new JLabel(Fig1);
        this.add(this.etiqueta1);
        this.add(new JLabel("Fig. 1"));
        
        this.Fig2 = new ImageIcon("Fig2.png");
        this.etiqueta2 = new JLabel(Fig2);
        this.add(this.etiqueta2);
        this.add(new JLabel("Fig. 2"));
        
        this.Fig3 = new ImageIcon("Fig3.jpg");
        this.etiqueta3 = new JLabel(Fig3);
        this.add(this.etiqueta3);
        this.add(new JLabel("Fig. 3"));
    }
    
    
}

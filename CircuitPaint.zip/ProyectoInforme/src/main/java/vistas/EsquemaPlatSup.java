/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistas;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Alumno
 */
public class EsquemaPlatSup extends JPanel{

    public JButton buttonAtras;
    public JLabel titulo;
    private ImageIcon ima;
    private JLabel etiqueta;
    
    public EsquemaPlatSup() {
    
        inicializarComponentes();
    
    }
    
    public void inicializarComponentes(){
    
        
        FlowLayout flow = new FlowLayout();
        this.setLayout(flow);
        
        Font fuente=new Font("Dialog", Font.BOLD, 40);
        
        this.buttonAtras = new JButton("Cerrar Sesión");
        this.add(this.buttonAtras);
        this.add(new JLabel("                      "));
        
        
        this.titulo = new JLabel("Relájate, hay cosas que llevan su tiempo… ");
        this.titulo.setFont(fuente);
        this.add(this.titulo);
        this.add(new JLabel("                         "));
        
        this.ima = new ImageIcon("homeroPensando.png");
        this.etiqueta = new JLabel(ima);
        this.add(this.etiqueta);
        this.setBackground(Color.CYAN);
        
    }
    
    
}

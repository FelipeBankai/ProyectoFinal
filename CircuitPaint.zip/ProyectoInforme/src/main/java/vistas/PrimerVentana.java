/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistas;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author Alumno
 */
public class PrimerVentana extends JFrame implements ActionListener{

    private LoginPlatCenter texto;
    private LoginPlatInfe boton;
    private LoginPlatSup salir;
    
    public PrimerVentana() {
    
        inicializarComponentes();
        
    }
    
    public void inicializarComponentes(){
    
        this.salir = new LoginPlatSup();
        this.add(this.salir, BorderLayout.NORTH);
        
        this.texto = new LoginPlatCenter();
        this.add(this.texto, BorderLayout.CENTER);
        
        this.boton = new LoginPlatInfe();
        this.add(this.boton, BorderLayout.SOUTH);
        
        this.boton.entrar.addActionListener(this);
        this.salir.butonExis.addActionListener(this);
        this.setDefaultCloseOperation( EXIT_ON_CLOSE );
        
        this.setTitle( "CircuitPaint" );
        ImageIcon ImageIcon = new ImageIcon("atomo.png");
        Image image = ImageIcon.getImage();
        this.setIconImage(image);
        this.setBounds(500, 250, 350, 150);
        this.setUndecorated(true);
        this.setVisible(true);
    
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    
        if (this.boton.entrar == e.getSource()) {
            String usuario = "Usuario";
            String contrasegna = "code99";
            String Pass = new String(this.texto.txtContra.getPassword());
            if (this.texto.txtUsuario.getText().equals(usuario) || Pass.equals(contrasegna)) {
                
                SegundaVentana v2 = new SegundaVentana();
                v2.setVisible(true);
                this.setVisible(false);
                
            }else{
            
                JOptionPane.showMessageDialog(null, "Llene todos los campos de textos correctamente");
                
            }
        }
        if (this.salir.butonExis == e.getSource()) {
            
            System.exit(0);
            this.dispose();
        }
        
        
    }
    
    
}

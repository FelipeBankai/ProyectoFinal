/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistas;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author Alumno
 */
public class LoginPlatCenter extends JPanel{

    private JLabel labelUsuario;
    private JLabel labelContra;
    public JTextField txtUsuario;
    public JPasswordField txtContra;
    
    public LoginPlatCenter() {
    
        inicializarComponentes();
    
    }
    
    public void inicializarComponentes(){
    
        this.setBackground(Color.CYAN);
        
        GridLayout grid = new GridLayout(2, 4);
        this.setLayout(grid);
        
        this.labelUsuario = new JLabel("Nombre");
        this.add(this.labelUsuario);
        
        this.txtUsuario = new JTextField();
        this.add(this.txtUsuario);
        
        this.labelContra = new JLabel("Contraseña");
        this.add(this.labelContra);
        
        this.txtContra = new JPasswordField();
        this.add(this.txtContra);
        
        
    }
    
    
    
}

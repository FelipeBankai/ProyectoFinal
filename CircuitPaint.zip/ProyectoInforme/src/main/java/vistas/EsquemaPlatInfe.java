/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistas;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author Alumno
 */
public class EsquemaPlatInfe extends JPanel{
    
    public JButton ayuda;

    public EsquemaPlatInfe() {
    
        inicializarComponentes();
        
    }
    
    public void inicializarComponentes(){
    
        
        Font fuente=new Font("Dialog", Font.BOLD, 25);
        
        this.setBackground(Color.CYAN);
        
        this.ayuda = new JButton("Ayuda");
        this.ayuda.setFont(fuente);
        this.add(this.ayuda);
    }
    
}
